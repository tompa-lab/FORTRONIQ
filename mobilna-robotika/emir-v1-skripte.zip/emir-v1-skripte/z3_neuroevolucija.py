# Exercise 3: neural network 10-n-n-2 drives eMIR, a genetic algorithm learns the weights.
import math, random
from emir_sim import POLYGONS, CELL, GW, GH, W_MAX, segments, lidar, kinematics_step

def n_weights(n):
    return 10 * n + n + n * n + n + 2 * n + 2

def input_fn(d):                      # input activation, code in figure 12 of the thesis
    return 16 / (1 + math.exp(0.55 - 3 * d)) - 8

def leaky(x):                         # modified LeakyReLU: x/5 for negative values
    return x if x > 0 else x / 5

def forward(g, n, dist):
    """Feedforward: 10 distances [m] -> 2 wheel outputs 0-10."""
    inp = [input_fn(d) for d in dist]
    o = 0
    h1 = [sum(inp[i] * g[o + i * n + j] for i in range(10)) for j in range(n)]; o += 10 * n
    h1 = [leaky(h1[j] + g[o + j]) for j in range(n)]; o += n
    h2 = [sum(h1[i] * g[o + i * n + j] for i in range(n)) for j in range(n)]; o += n * n
    h2 = [leaky(h2[j] + g[o + j]) for j in range(n)]; o += n
    z = [sum(h2[i] * g[o + i * 2 + j] for i in range(n)) for j in range(2)]; o += 2 * n
    return [10 / (1 + math.exp(-leaky(z[j] + g[o + j]))) for j in range(2)]

def run(g, n, poly, start=0, see=1.0):
    """One drive until collision, output <= 3.5 or 1000 iterations. Returns the score (equation 18)."""
    segs = segments(poly); x, y, th = poly["starts"][start]
    seen = set(); steps = 0; dist = 0.0; s_v = s_dif = s_ang = 0.0
    while steps < 1000:
        scan = lidar(segs, x, y, th); d = [s[0] for s in scan]
        for i, di in enumerate(d):
            a = th + math.radians(36 * i)
            for k in range(int(min(di, see) / CELL) + 1):
                gx, gy = int((x + math.cos(a) * k * CELL) / CELL), int((y + math.sin(a) * k * CELL) / CELL)
                if 0 <= gx < GW and 0 <= gy < GH:
                    seen.add(gy * GW + gx)
        if min(d) <= 0.2:
            break                                         # reset: too close (figure 12)
        out = forward(g, n, d)
        if not (out[0] and out[1] > 3.5):
            break                                         # reset: output too small (figure 12)
        x0, y0 = x, y
        x, y, th = kinematics_step(x, y, th, out[0] / 10 * W_MAX, out[1] / 10 * W_MAX)
        dist += math.hypot(x - x0, y - y0); steps += 1
        s_v += (out[0] + out[1]) / 2; s_dif += 10 - abs(out[0] - out[1])
        far = max(range(10), key=lambda i: d[i]); ang = far * 36; s_ang += 360 - ang if ang > 180 else ang
    k = max(1, steps)
    parts = {"speed": 50 * s_v / k, "difference": 50 * s_dif / k, "exploration": 1.000488 ** len(seen),
             "loops": steps / 2, "distance": min(1000, dist * 100) / 2, "angle": 10 * (1 - s_ang / k / 180)}
    return sum(parts.values()), parts, steps, len(seen)

def random_net(n):
    return [random.uniform(-0.999, 0.999) for _ in range(n_weights(n))]

def crossover(a, b, sa, sb):
    p = sa / (sa + sb)                                    # share of the better network
    return [wa if random.random() < p else wb for wa, wb in zip(a, b)]

def mutate(g, k=6):
    m = list(g)
    for _ in range(k):
        m[random.randrange(len(m))] = random.uniform(-0.999, 0.999)
    return m

if __name__ == "__main__":
    # 1) check the input function against figure 10 of the thesis
    for d, expected in [(0.678, 5.043), (1.811, 7.88), (0.329, 1.719)]:
        print(f"input_fn({d}) = {input_fn(d):.3f}   (thesis: {expected})")
    # 2) load example weights from a text file (as on the robot's Raspberry Pi) and drive
    g = [float(v) for v in open("emir_tezine_primjer.txt")]
    score, parts, steps, ex = run(g, 10, POLYGONS[0])
    print(f"Example network on Polygon 1, start 1: {steps} iterations, {ex} cells, score {score:.0f}")
    print("   " + ", ".join(f"{k} {v:.0f}" for k, v in parts.items()))
    # 3) a short genetic algorithm from random weights (population 20, 4 generations)
    random.seed(1); n = 5; pop = [random_net(n) for _ in range(20)]
    for gen in range(4):
        scores = [sum(run(net, n, POLYGONS[k])[0] for k in range(3)) / 3 for net in pop]
        order = sorted(range(len(pop)), key=lambda i: -scores[i])
        best, second = pop[order[0]], pop[order[1]]
        print(f"Generation {gen}: best {scores[order[0]]:.0f}, second {scores[order[1]]:.0f}")
        child = crossover(best, second, scores[order[0]], scores[order[1]])
        pop = [best, child] + [mutate(child) for _ in range(18)]
    with open("emir_tezine_najbolja.txt", "w") as f:
        f.write("\n".join(repr(w) for w in best) + "\n")
    print("Best weights saved to emir_tezine_najbolja.txt")
