# Simulator of the eMIR mobile robot on the 4 x 2 m polygon (pure Python, no simulator needed).
# Same model as the interactive page: differential drive, 10-beam LiDAR, 2 cm map.
import math

PW, PH = 4.0, 2.0          # polygon size [m]
L, R = 0.24, 0.04          # wheel distance and wheel radius [m]
W_MAX = 4.61               # max wheel speed [rad/s] -> 185 mm/s
DT = 0.05                  # control step [s]
CELL, GW, GH = 0.02, 200, 100   # map: 2 cm cells, 200 x 100


def circle(cx, cy, r, n=28):
    return [(cx + r * math.cos(2 * math.pi * i / n), cy + r * math.sin(2 * math.pi * i / n)) for i in range(n)]


def square(cx, cy, s):
    h = s / 2
    return [(cx - h, cy - h), (cx + h, cy - h), (cx + h, cy + h), (cx - h, cy + h)]


def triangle(cx, cy, s):
    h = s * math.sqrt(3) / 2
    return [(cx - s / 2, cy - h / 3), (cx + s / 2, cy - h / 3), (cx, cy + 2 * h / 3)]


def l_shape(x0, y0, mirror=False):
    s, t = 0.52, 0.52 / 3
    pts = [(0, 0), (s, 0), (s, t), (t, t), (t, s), (0, s)]
    return [(x0 + (s - x if mirror else x), y0 + y) for x, y in pts]


def arc_shape(cx, cy, a0, a1, rout=0.51, rin=0.245, n=14):
    out = [(cx + rout * math.cos(math.radians(a0 + (a1 - a0) * i / n)), cy + rout * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]
    inn = [(cx + rin * math.cos(math.radians(a0 + (a1 - a0) * i / n)), cy + rin * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n, -1, -1)]
    return out + inn


COLOR = {"tri": "blue", "cir": "green", "sq": "red", "L": "black", "J": "black"}
SHAPE = {"tri": "triangle", "cir": "circle", "sq": "square", "L": "L-polygon", "J": "rounded polygon"}
# Table 2 of the thesis: bounding-box area / object area
RATIO = {"triangle": (1.9, 2.1), "circle": (1.15, 1.4), "square": (0.9, 1.1), "L-polygon": (1.7, 1.85), "rounded polygon": (1.5, 1.67)}

# Object layout read from figure 5c of the thesis (coordinates are not given there)
POLYGONS = [
    {"name": "Polygon 1",
     "objects": [("L", l_shape(0.51, 0.53)), ("cir", circle(1.49, 1.35, 0.10)), ("sq", square(2.53, 1.35, 0.22)),
                 ("tri", triangle(2.0, 0.61, 0.24)), ("J", arc_shape(2.98, 1.05, -90, 0))],
     "starts": [(0.27, 0.30, 0.0), (3.67, 1.71, math.pi), (1.49, 1.00, -math.pi / 2), (2.53, 1.00, -math.pi / 2)]},
    {"name": "Polygon 2",
     "objects": [("J", arc_shape(1.04, 0.95, 90, 180)), ("cir", circle(1.74, 1.23, 0.10)), ("sq", square(2.57, 1.35, 0.22)),
                 ("tri", triangle(1.28, 0.61, 0.24)), ("L", l_shape(2.98, 0.53, True))],
     "starts": [(0.29, 0.30, 0.0), (3.67, 1.71, math.pi), (0.98, 0.86, -math.pi / 2), (3.00, 1.12, math.pi / 2)]},
    {"name": "Polygon 3",
     "objects": [("cir", circle(0.61, 1.35, 0.10)), ("J", arc_shape(0.94, 1.04, -90, 0)), ("L", l_shape(2.02, 0.53)),
                 ("sq", square(2.90, 1.35, 0.22)), ("tri", triangle(3.32, 0.61, 0.24))],
     "starts": [(0.29, 0.30, 0.0), (3.64, 1.71, math.pi), (0.96, 1.13, math.pi / 2), (2.90, 0.85, -math.pi / 2)]},
]


def segments(polygon):
    """All wall and object edges as (x1, y1, x2, y2, owner); owner -1 is a wall."""
    segs = [(0, 0, PW, 0, -1), (PW, 0, PW, PH, -1), (PW, PH, 0, PH, -1), (0, PH, 0, 0, -1)]
    for k, (_, pts) in enumerate(polygon["objects"]):
        for i in range(len(pts)):
            (x1, y1), (x2, y2) = pts[i], pts[(i + 1) % len(pts)]
            segs.append((x1, y1, x2, y2, k))
    return segs


def ray(segs, x, y, angle, max_dist=12.0):
    """Distance along one beam to the nearest edge, and who was hit."""
    dx, dy = math.cos(angle), math.sin(angle)
    best, who = max_dist, -2
    for x1, y1, x2, y2, owner in segs:
        ex, ey = x2 - x1, y2 - y1
        den = dx * ey - dy * ex
        if abs(den) < 1e-12:
            continue
        wx, wy = x1 - x, y1 - y
        t = (wx * ey - wy * ex) / den
        u = (wx * dy - wy * dx) / den
        if 0 < t < best and 0 <= u <= 1:
            best, who = t, owner
    return best, who


def lidar(segs, x, y, theta):
    """10 beams, one every 36 degrees, beam 0 points forward."""
    return [ray(segs, x, y, theta + math.radians(36 * i)) for i in range(10)]


def kinematics_step(x, y, theta, w_left, w_right, dt=DT):
    """Equations (13)-(15) of the thesis, one step of length dt."""
    v = R / 2 * (w_right + w_left)
    w = R / L * (w_right - w_left)
    theta = theta + w * dt
    return x + v * math.cos(theta) * dt, y + v * math.sin(theta) * dt, theta
