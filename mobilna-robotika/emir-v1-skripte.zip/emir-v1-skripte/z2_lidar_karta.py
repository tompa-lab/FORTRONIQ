# Exercise 2: LiDAR with 10 beams builds the cognitive map of the polygon.
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from emir_sim import POLYGONS, PW, PH, CELL, GW, GH, W_MAX, segments, lidar, kinematics_step, COLOR, SHAPE, RATIO

poly = POLYGONS[0]
segs = segments(poly)
x, y, th = poly["starts"][0]
seen = [[0] * GW for _ in range(GH)]       # 1 = free space seen by a beam
occ = [[-9] * GW for _ in range(GH)]       # owner of the hit cell (-1 wall, 0..4 object)
SEE = 1.0                                  # a beam "explores" cells up to 1 m (estimate)

def mark(x, y, angle, dist, who):
    for k in range(int(min(dist, SEE) / CELL) + 1):
        gx, gy = int((x + math.cos(angle) * k * CELL) / CELL), int((y + math.sin(angle) * k * CELL) / CELL)
        if 0 <= gx < GW and 0 <= gy < GH:
            seen[gy][gx] = 1
    hx, hy = int((x + math.cos(angle) * dist) / CELL), int((y + math.sin(angle) * dist) / CELL)
    if 0 <= hx < GW and 0 <= hy < GH:
        occ[hy][hx] = who

path = [(x, y)]
for step in range(1000):
    scan = lidar(segs, x, y, th)
    for i, (d, who) in enumerate(scan):
        mark(x, y, th + math.radians(36 * i), d, who)
    front = min(scan[0][0], scan[1][0], scan[9][0])
    left = min(scan[1][0], scan[2][0], 1.0)      # free space on the left (capped at 1 m)
    right = min(scan[9][0], scan[8][0], 1.0)     # free space on the right
    # simple rule (not the neural network): turn towards the side with more free space
    turn = 6 * (left - right)
    if front < 0.5:
        turn += 4 if left >= right else -4
    out_l = max(2, min(10, 7 - turn))
    out_r = max(2, min(10, 7 + turn))
    x, y, th = kinematics_step(x, y, th, out_l / 10 * W_MAX, out_r / 10 * W_MAX)
    path.append((x, y))
    if min(d for d, _ in scan) <= 0.2:
        print("Stopped: a beam measured 0.2 m or less"); break

explored = sum(map(sum, seen))
print(f"Steps: {step + 1}   explored cells: {explored} of {GW * GH} ({100 * explored / (GW * GH):.1f} %)")

# What did eMIR find?  Region (3 x 3) from the hit cells, shape from Table 2.
for k, (kind, pts) in enumerate(poly["objects"]):
    cells = [(gx, gy) for gy in range(GH) for gx in range(GW) if occ[gy][gx] == k]
    if len(cells) < 8:
        continue
    cx = sum(c[0] for c in cells) / len(cells) * CELL
    cy = sum(c[1] for c in cells) / len(cells) * CELL
    ew = "west" if cx < PW / 3 else "centre" if cx < 2 * PW / 3 else "east"
    ns = "south" if cy < PH / 3 else "centre" if cy < 2 * PH / 3 else "north"
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    area = abs(sum(pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1] for i in range(len(pts)))) / 2
    ratio = (max(xs) - min(xs)) * (max(ys) - min(ys)) / area
    shape = next((s for s, (lo, hi) in RATIO.items() if lo <= ratio <= hi), "unknown")
    print(f"eMIR: {COLOR[kind]} {shape}, {ns} {ew} (ratio {ratio:.2f}, {len(cells)} hit cells)")

img = [[(1, 1, 1) if seen[gy][gx] else (.85, .87, .88) for gx in range(GW)] for gy in range(GH)]
for gy in range(GH):
    for gx in range(GW):
        if occ[gy][gx] >= -1:
            img[gy][gx] = (.1, .1, .1) if occ[gy][gx] == -1 else {"blue": (.2, .4, .85), "green": (.2, .6, .3), "red": (.85, .25, .2), "black": (.2, .2, .2)}[COLOR[poly["objects"][occ[gy][gx]][0]]]
plt.figure(figsize=(8, 4.2))
plt.imshow(img, origin="lower", extent=(0, PW, 0, PH))
plt.plot(*zip(*path), color="tab:green", lw=1)
plt.title("Cognitive map 200 x 100 (2 cm)"); plt.xlabel("x [m]"); plt.ylabel("y [m]")
plt.tight_layout(); plt.savefig("z2_karta.png", dpi=150)
