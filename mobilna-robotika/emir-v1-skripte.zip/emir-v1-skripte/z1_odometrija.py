# Exercise 1: wheel speeds are given, the position is calculated (odometry).
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from emir_sim import R, L, W_MAX, DT, kinematics_step

TICKS_PER_REV = 497            # encoder ticks per wheel revolution (estimate: 364 ticks/s at 0.733 rev/s)
R_REAL = 0.0405                # real wheel radius is 0.5 mm larger than nominal (tyre)

# Command profile: (duration [s], left output 0-10, right output 0-10)
profile = [(4.0, 8, 8), (2.0, 4, 8), (4.0, 8, 8), (3.0, 8, 4), (5.0, 6, 9)]

x = y = th = 0.0               # "true" robot (fine time step, real radius)
ox = oy = oth = 0.0            # odometry (50 ms step, encoder ticks, nominal radius)
true_path, odo_path = [(0, 0)], [(0, 0)]
acc_l = acc_r = 0.0            # wheel angle not yet counted as a full tick

for duration, out_l, out_r in profile:
    w_l, w_r = out_l / 10 * W_MAX, out_r / 10 * W_MAX          # 0-10 -> rad/s
    for _ in range(round(duration / DT)):
        # true motion: 50 sub-steps of 1 ms with the real wheel radius
        for _ in range(50):
            v = R_REAL / 2 * (w_r + w_l); w = R_REAL / L * (w_r - w_l)
            th += w * 0.001; x += v * math.cos(th) * 0.001; y += v * math.sin(th) * 0.001
        # encoders: count whole ticks in this 50 ms step
        acc_l += w_l * DT / (2 * math.pi) * TICKS_PER_REV
        acc_r += w_r * DT / (2 * math.pi) * TICKS_PER_REV
        n_l, n_r = math.floor(acc_l), math.floor(acc_r)
        acc_l -= n_l; acc_r -= n_r
        wl_meas = n_l / TICKS_PER_REV * 2 * math.pi / DT          # measured wheel speeds
        wr_meas = n_r / TICKS_PER_REV * 2 * math.pi / DT
        ox, oy, oth = kinematics_step(ox, oy, oth, wl_meas, wr_meas)   # equations (13)-(15)
        true_path.append((x, y)); odo_path.append((ox, oy))

err = math.hypot(x - ox, y - oy)
print(f"True position     x = {x:.3f} m  y = {y:.3f} m  theta = {math.degrees(th):.1f} deg")
print(f"Odometry position x = {ox:.3f} m  y = {oy:.3f} m  theta = {math.degrees(oth):.1f} deg")
print(f"Position error after {sum(p[0] for p in profile):.0f} s: {err*1000:.0f} mm")

plt.figure(figsize=(7, 4))
plt.plot(*zip(*true_path), label="true path")
plt.plot(*zip(*odo_path), "--", label="odometry")
plt.axis("equal"); plt.grid(alpha=.3); plt.legend(); plt.xlabel("x [m]"); plt.ylabel("y [m]")
plt.tight_layout(); plt.savefig("z1_odometrija.png", dpi=150)
